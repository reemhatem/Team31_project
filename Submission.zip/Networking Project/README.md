# P2P-Chatting-And-File-Sharing-App
A real time chatting application based on P2P client server. Two client is connected through their IP address and Port Number. 
Proper GUI is developed like Facebook Messenger or WhatsApp Messenger. The app also has File Sharing and Chat Saving Features. 
Initially the homescreen will look like this ![Alt text](screen/1.JPG?raw=true "Optional Title")

After providing an User Name, IP Address of another end, port number to listen and send message the app will forward to a chatting window.
The chatting window will look like this 



![Alt text](screen/2.jpg?raw=true "Optional Title2")






This app will allow seamless chatting and file sharing facilities while the to end system is connected through socket. The app also provide facility to change the chat color or theme from any one end which will affect the other end. The following screen shows the theme changing facility 



![Alt text](screen/3.jpg?raw=true "Optional Title3")


Upon Receiving a file the app provide option to save in the local drive. Following shows the app screenshot for this 

![Alt text](screen/4.jpg?raw=true "Optional Title")


After successfull save the the app promt the user to open the saved location to get the desired file. It behaves the following way 


![Alt text](screen/5.jpg?raw=true "Optional Title")
