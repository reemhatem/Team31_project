package message;
import java.io.*;
import java.util.Scanner;
import java.nio.ByteBuffer;
import javax.imageio.ImageIO;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.awt.image.DataBufferByte;

public class Steganographer {

	private static int thelongs = 8;
	private static int theshorts = 4;
	

	public static void main(String[] args){
//		encode("bigie.png","mssg.txt");
//		String s = "lailaaa.png";
//		decode(s);
//		String s= "C:\Users\lenovo\eclipseworkspace\Networking Project\downloadd_with_hidden_message.png";
//		BufferedImage imageFromPath = getImageFromPath(s);
//		System.out.println("GEEEETTTT IMAGEEE"+imageFromPath);
//		BufferedImage imageInUserSpace = getImageInUserSpace(imageFromPath);
//		System.out.println(imageInUserSpace);
		//		encode("downloadd.png","results.txt");
//		decode("downloadd_with_hidden_message.png");
		
	}



//	public static void run(String input1,String input2) {
//		System.out.println("JJJJJJJJJJJJJJJJJJJ"+input1);
//		
//		
//		if(input2== "") {
//			decode(input1);
//			return;
//		}else {
//			encode(input1, input2);
//			return;
//			
//		}
//		
//	}
	public static void encode(String im1, String tth) {
		System.out.println("IMAGEPATH"+im1);
		System.out.println("TXTTTTTTT"+ tth);
		BufferedImage originalImage = getpth(im1);
		BufferedImage imspace = newimgtoget(originalImage);
		String inpp = extractsecret(tth);
		System.out.println("THIS IS MY TXXXXXXXT"+ inpp);

		byte byteimg[] = imbyt(imspace);
		byte bytetxt[] = inpp.getBytes();
		
		
		
		byte textLengthInBytes[] = bytestogetinhere(bytetxt.length);
		try {
			helperencode(byteimg, textLengthInBytes,  0); 
			helperencode(byteimg, bytetxt, theshorts*thelongs);
		}
		catch (Exception exception) {
			System.out.println("Exception found!: " + exception);
			return;
		}
		
		String thenew = im1;
		int xy = thenew.lastIndexOf(".");
		if (xy > 0) {
			thenew = thenew.substring(0, xy);
		}
		
		String finalFileName = "downloadd" + "_with_hidden_message.png";
		System.out.println("Successfully encoded text in: " + finalFileName);
		tonewplace(imspace, new File(finalFileName),"png");
		return;
	}

	private static byte[] helperencode(byte[] input, byte[] theplus, int movement) {
		if (theplus.length + movement > input.length) {
			throw new IllegalArgumentException("Small picture");
		}
//		if(input2== "") {
//			decode(input1);
//			return;
//		}else {
//			encode(input1, input2);
//			return;
		for (int i=0; i<theplus.length; i++) {
			int additionByte = theplus[i];
			for (int bit=thelongs-1; bit>=0; --bit, movement++) { 
				int b = (additionByte >>> bit) & 0x1;
				input[movement] = (byte)((input[movement] & 0xFE) | b); 
				System.out.println("ENCODEIMGGGGGGGGGGGG "+ b+" "+ input[movement]);
			}
		}
//		syso
//		BufferedImage imageInUserSpace = getImageInUserSpace(imageFromPath);
//		System.out.println(imageInUserSpace);
		//		encode("downloadd.png","results.txt");
		
		return input;
	}




	public static String decode(String todecode) {
		byte[] thetext;
		try {
			System.out.println("PAAAAAAAAAAAAATH "+todecode);
			BufferedImage impth = getpth(todecode);
			System.out.println("GEEEETTTT IMAGEEE"+impth);
			BufferedImage imspc = newimgtoget(impth);
			System.out.println(imspc);

			byte newim[] = imbyt(imspc);
//			System.out.println(imspc);
			thetext = helpdec(newim);
			String secret = new String(thetext);
			System.out.println(secret);
			String newfile = "hidden_text.txt";
			newplace(secret, new File(newfile));
			System.out.println("Successfully extracted text to: " + newfile);
			System.out.println(secret.length());
			System.out.println("jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj"+secret);
			return secret;
		} catch (Exception exception) {
			System.out.println("Secret not found");
			System.out.println(exception);
			return "";
		}
	}

	private static byte[] helpdec(byte[] imin) {
		System.out.println(imin);
		
		int thepush  = theshorts*thelongs;
		int c = 0;
		
		for (int i=0; i<thepush; i++) {
			c = (c << 1) | (imin[i] & 0x1);
		}
		
		byte[] output = new byte[c];

		for (int b=0; b<output.length; b++ ) {
			for (int i=0; i<thelongs; i++, thepush++) {
				output[b] = (byte)((output[b] << 1) | (imin[thepush] & 0x1));
			}
		}
		return output;
		// System.out.println("theeeee outtputttt isss hereeee");
		// System.out.println(output.length());
		// System.out.println(output);
	}


	

	private static void tonewplace(BufferedImage tosave, File inp, String theextra) {
		Boolean t=false;
		try {
			inp.delete(); 
			ImageIO.write(tosave, theextra, inp);
		} catch (Exception exception) {
			System.out.println("Not loaded correctly");
			System.out.println(exception);
		}
	}

	private static void newplace(String secretmsg, File theinput) {
		System.out.println(secretmsg);
//		System.out.println(theinput);
		try {	
			if (theinput.exists() == false) {
				theinput.createNewFile( );
			}
			FileWriter towrite = new FileWriter(theinput.getAbsoluteFile());
			BufferedWriter yarab = new BufferedWriter(towrite);
			yarab.write(secretmsg);
			yarab.close();
		} catch (Exception exception) {
//			System.out.println("111111111111111111111111111111111111");
			System.out.println("Secret msg too secret");
			System.out.println(exception);
		}
	}
	
	private static String extractsecret(String mesg) {
		String inpt = "";
		System.out.println(mesg);
		
		try {
			Scanner cno = new Scanner( new File(mesg) );
			inpt = cno.useDelimiter("\\A").next();
			cno.close();
//			System.out.println(inpt);
		} catch (Exception exception) {
//			System.out.println("noo");
			System.out.println("No secret here");
			System.out.println(exception);
		}
//		System.out.println(inpt);
		return inpt;
	}

	private static BufferedImage getpth(String address) {
		
		File ournew = new File(address);
		BufferedImage pics	= null;
		try {
			pics = ImageIO.read(ournew);
			
		} catch (Exception exception) {
			System.out.println("Wrong picture");
			System.out.println(exception);
		}
		return pics;
	}




	private static byte[] bytestogetinhere(int numb) {
		return ByteBuffer.allocate(theshorts).putInt(numb).array();
	}
	
	private static BufferedImage newimgtoget(BufferedImage theimgtoget) {
		BufferedImage usp  = new BufferedImage(theimgtoget.getWidth(), theimgtoget.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
		Graphics2D paintted = usp.createGraphics();
		paintted.drawRenderedImage(theimgtoget, null);
		paintted.dispose(); 
		return usp;
	}

	private static byte[] imbyt(BufferedImage pics) {
		WritableRaster tke1 = pics.getRaster();
		DataBufferByte queuetoget = (DataBufferByte)tke1.getDataBuffer();
		return queuetoget.getData();
	}


}
