package application;
	
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.awt.Font;
import java.awt.TextArea;
import java.awt.TextField;
import java.io.IOException;

import javax.swing.JTextField;
import javax.swing.UIManager;

import application.Authentication;

public class Main extends Application {
	private Pane root;
	private Parent chatScreen;
	private Scene scene;
	private MainController mainController;
	@FXML private ImageView homeImage;
	public char[] password;
	
	public char[] getPassword() {
		return password;
	}
	
	@Override
	public void start(Stage primaryStage) {
		try {
			
			root = FXMLLoader.load(getClass().getResource("WelcomeScreen.fxml"));
			System.out.println(root.lookup("#anotherButton"));
			chatScreen = FXMLLoader.load(getClass().getResource("ChatScreen.fxml"));
			scene = new Scene(root,600,650);
			scene.getStylesheets().add(getClass().getResource("listStyle.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setTitle("Welcome");
			primaryStage.setResizable(false);
			primaryStage.show();
			mainController = new MainController(this);
			mainController.setStage(primaryStage);
			
			password = Authentication.password_Gener(5);
		    char[] c= password;
		    String s="";
		    for (int i =0; i<c.length;i++) {
		    	s+=c[i];
		    }

//			System.out.println("PAAAAAAAAAAAS "+password);
		   
//		    
			Label infoMessage = new Label(" YOUR PASSWORD : ");
			Label pwd= new Label(s);
		    infoMessage.setStyle("-fx-font-size:15;-fx-padding:10;");
		   
		    pwd.setStyle("-fx-font-size:15;-fx-padding:50;");
		   
		    
		    VBox vbox = new VBox(infoMessage,pwd);
		   
		    Alert alert = new Alert(AlertType.INFORMATION);
		    alert.setTitle("PASSWORD");
		    alert.setHeaderText("YOUR ONE TIME PASSWORD");
		    alert.getDialogPane().setContent(vbox);
		    alert.show();
			System.out.println(c);
			
		} catch(Exception e) {
			System.out.println("There is a problem");
			e.printStackTrace();
		}
	}
	
	private void add(JTextField f) {
		// TODO Auto-generated method stub
		
	}

	public void setRoot(Pane root)
	{
		this.root = root;
		scene.setRoot(root);
	}
	
	
	
	public Pane getRoot() {
		return root;
	}

	public static void main(String[] args) {
		launch(args);
	}
}
